from odoo import models, fields, api, _,Command
from odoo.exceptions import UserError
import logging
import requests
import xml.etree.ElementTree as ET
import pandas as pd
from odoo.exceptions import ValidationError  # Import ValidationError
from dateutil.relativedelta import relativedelta


_logger = logging.getLogger(__name__)



class Waybill(models.Model):
    _name = 'waybill'
    _description = 'Waybill'

    waybill_line_history_ids = fields.One2many('waybill.line.history', 'waybill_id', string='Waybill Line Histories')
    waybill_id_number = fields.Char(string='ზედნადების ID')
    waybill_number = fields.Char(string='ზედნადების ნომერი')
    waybill_type = fields.Char(string='ზედნადების ტიპი')
    create_date = fields.Char(string='შექმნის თარიღი')
    buyer_tin = fields.Char(string='მყიდველის საიდენტიფიკაციო')
    buyer_name = fields.Char(string='მყიდველის სახელი')
    seller_name = fields.Char(string='გამყიდველის სახელი')
    seller_tin = fields.Char(string='გამყიდველის საიდინტიფიკაციო')
    start_address = fields.Char(string='საწყისი მისამართი')
    end_address = fields.Char(string='საბოლოო მისამართი')
    transport_cost = fields.Float(string='ტრანსპორტირების ფასი')
    full_amount = fields.Float(string='მთლიანი ფასი')
    activate_date = fields.Char(string='აქტივაციის რიცხვი')
    s_user_id = fields.Integer(string='გამყიდველის User ID')
    begin_date = fields.Char(string='საწყისი თარიღი')
    is_confirmed = fields.Char(string='დადასტურებულია')
    is_corrected = fields.Char(string='დაკორეკტირებულია')
    seller_st = fields.Char(string='Seller ST')
    is_med = fields.Boolean(string='ჯანდაცვა')
    waybill_comment = fields.Text(string='კომენტარი')
    driver_tin = fields.Char(string='მძღოლის პირადი ნომერი')
    driver_name = fields.Char(string='მძღოლის სახელი')
    car_number = fields.Char(string='მანქანის ნომერი')
    delivery_date = fields.Char(string='მიტანის თარიღი')
    close_date = fields.Char(string='დახურვის თარიღი')
    invoice_id = fields.Char(string='ფაქტურის ID')
    line_ids = fields.One2many('waybill.line', 'waybill_id', string='Lines', ondelete='cascade')
    error_text = fields.Text(string='შეცდომის ტექსტი')
    product_id = fields.Many2one('product.template', string='Product', ondelete='set null')
    xarjang = fields.Many2one('account.account', string='დებეტი|დებეტის ანგარიში')
    xarjgat = fields.Boolean(string='დებეტი|დებეტის ანგარიში')
    katId_O = fields.Char(string='katId_O')
    katName_O = fields.Char(string='პროდ.კატ|პროდუქციის კატეგორია')
    stock_Name = fields.Char(string='საწყობი')
    stockId1 = fields.Many2one('stock.location', string='Stock Location 2', help="Link to the first stock location.")
    stockId2 = fields.Many2one('stock.location', string='Stock Location 1', help="Link to the second stock location.")
    mdgomareoba = fields.Selection([
        ('korektirebuli', 'Korektirebuli'),
        ('gadatanili', 'Gadatanili'),
        ('araferi', 'Araferi')
    ], string='Mdgomareoba', default='araferi')
    
    @api.depends('waybill_type')
    def _compute_is_trans_id_4(self):
        for record in self:
            record.is_trans_id_4 = record.waybill_type == '1'
            
    is_trans_id_4 = fields.Boolean(compute='_compute_is_trans_id_4')


    # Add Product Category field here
    product_category_id = fields.Many2one(
        'product.category',
        string='Product Category',
        help='Select the product category for this waybill.'
    )
    @api.onchange('product_category_id')
    def _onchange_product_category_id(self):
        for line in self.line_ids:
            line.product_category_id = self.product_category_id

    def _get_field_visibility(self):
        for record in self:
            if record.waybill_type != 1:
                return False
        return True




    @api.onchange('xarjang')
    def _onchange_xarjang(self):
        if self.xarjang:
            for line in self.line_ids:
                line.xarjang = self.xarjang


    def button_fetch_waybill_data(self):
        waybill_id = self.waybill_number
        if not waybill_id:
            raise UserError("Please provide a waybill number before fetching data.")
        return self.fetch_waybill_data(waybill_id)

    @api.model
    def fetch_waybill_data(self, waybill_id):
        _logger.info(f"Attempting to fetch data for waybill ID: {waybill_id}")
        waybill_id_number = self.waybill_id_number
        rs_acc = 'NEWTESTDATO:206322102'
        rs_pass = '123456'
        url = "http://services.rs.ge/WayBillService/WayBillService.asmx"
        headers = {
            "Content-Type": "text/xml; charset=utf-8",
            "SOAPAction": "http://tempuri.org/get_waybill"
        }
        payload = f"""<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                  <soap:Body>
                    <get_waybill xmlns="http://tempuri.org/">
                      <su>NEWTESTDATO:206322102</su>
                      <sp>123456Ab!</sp>
                      <waybill_id>{waybill_id_number}</waybill_id>
                    </get_waybill>
                  </soap:Body>
                </soap:Envelope>"""
        response = requests.post(url, data=payload, headers=headers)
        response_text = response.text
        root = ET.fromstring(response_text)
        namespace = {'soap': 'http://schemas.xmlsoap.org/soap/envelope/'}
        self.error_text = response_text

        goods_list = []
        for goods in root.findall('.//GOODS', namespaces=namespace):
            item = {
                'w_name': goods.find('W_NAME').text.strip() if goods.find('W_NAME') is not None else 'arari',
                'quantity': goods.find('QUANTITY').text.strip() if goods.find('QUANTITY') is not None else 'arari',
                'price': goods.find('PRICE').text.strip() if goods.find('PRICE') is not None else 'arari',
                'amount': goods.find('AMOUNT').text.strip() if goods.find('AMOUNT') is not None else 'arari',
                'bar_code': goods.find('BAR_CODE').text.strip() if goods.find('BAR_CODE') is not None else 'arari',
                'a_id': goods.find('A_ID').text.strip() if goods.find('A_ID') is not None else 'arari',
                'vat_type': goods.find('VAT_TYPE').text.strip() if goods.find('VAT_TYPE') is not None else 'arari',
                'status': goods.find('STATUS').text.strip() if goods.find('STATUS') is not None else None,
                'quantity_fact': goods.find('QUANTITY_F').text.strip() if goods.find('QUANTITY_F') is not None else 'arari',
            }
            goods_list.append(item)

        _logger.info(f"Parsed {len(goods_list)} items from the API response")

        waybill_line_vals = []
        existing_waybill = self.search([('waybill_number', '=', waybill_id)], limit=1)
        if existing_waybill:
            _logger.info(f"Updating existing waybill with ID: {existing_waybill.id}")
            waybill_record = existing_waybill
            waybill_record.line_ids.unlink()  # Remove existing lines
        else:
            _logger.info(f"Creating new waybill record for waybill number: {waybill_id}")
            waybill_record = self.create({'waybill_number': waybill_id})

        for item in goods_list:
            # Check for matching buyer TIN and barcode in product.template.buyer.info
            product_buyer_info = self.env['product.template.buyer.info'].search([
                ('buyer_tin', '=', self.buyer_tin),
                ('barcode', '=', item['bar_code'])
            ], limit=1)

            if product_buyer_info:
                _logger.info(f"Linking waybill line to product: {product_buyer_info.product_id.name}")
                waybill_line_vals.append({
                    'waybill_id': waybill_record.id,
                    **item,
                    'product_id': product_buyer_info.product_id.id  # Link to the product
                })
            else:
                waybill_line_vals.append({
                    'waybill_id': waybill_record.id,
                    **item
                })

        self.env['waybill.line'].create(waybill_line_vals)
        _logger.info(f"Created {len(waybill_line_vals)} waybill lines for waybill ID: {waybill_id}")

        return {
            'type': 'ir.actions.act_window',
            'name': _('Waybill'),
            'res_model': 'waybill',
            'res_id': waybill_record.id,
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'current',
        }
    def action_open_fetch_waybills_wizard(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Fetch Waybills',
            'res_model': 'fetch.waybills.wizard',
            'view_mode': 'form',
            'view_id': self.env.ref('waybill_management_custom.view_fetch_waybills_wizard_form').id,
            'target': 'new',
        }

    def action_open_fetch_waybills_wizard1(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Fetch Waybills Wizard1',
            'res_model': 'fetch.waybills.wizard1',
            'view_mode': 'form',
            'view_id': self.env.ref('waybill_management_custom.view_fetch_waybills_wizard1_form').id,
            'target': 'new',
        }

    def action_open_fetch_waybills_wizard3(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Fetch Waybills Wizard3',
            'res_model': 'fetch.waybills.wizard3',
            'view_mode': 'form',
            'view_id': self.env.ref('waybill_management_custom.view_fetch_waybills_wizard3_form').id,
            'target': 'new',
        }
    def action_open_fetch_waybills_wizard4(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Fetch Waybills Wizard4',
            'res_model': 'fetch.waybills.wizard4',
            'view_mode': 'form',
            'view_id': self.env.ref('waybill_management_custom.view_fetch_waybills_wizard4_form').id,
            'target': 'new',
        }
    def action_open_fetch_waybills_wizard5(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Fetch Waybills Wizard5',
            'res_model': 'fetch.waybills.wizard5',
            'view_mode': 'form',
            'view_id': self.env.ref('waybill_management_custom.view_fetch_waybills_wizard5_form').id,
            'target': 'new',
        }

    vendor_bill_id = fields.Many2one('account.move', string='Vendor Bill', ondelete='set null')




    
    def create_vendor_bill(self):
        for waybill in self:
            # Check if a vendor already exists for the seller
            partner = self.env['res.partner'].search([
                ('vat', '=', waybill.seller_tin),
            ], limit=1)

            # If no vendor exists, create one
            if not partner:
                partner = self.env['res.partner'].create({
                    'name': waybill.seller_name,
                    'vat': waybill.seller_tin,
                })

            # Prepare invoice lines from waybill lines, skipping lines with xarjang value
            invoice_lines = []
            for line in waybill.line_ids:
                # Assuming xarjang is a field on the waybill.line model
                if not line.xarjang:
                    product = self._get_or_create_product(line.w_name)
                    invoice_lines.append((0, 0, {
                        'product_id': product.id,
                        'quantity': line.quantity,
                        'price_unit': line.price,
                    }))

            # Create vendor bill based on waybill data
            vendor_bill = self.env['account.move'].create({
                'move_type': 'in_invoice',  # Invoice type for vendor bills
                'partner_id': partner.id,
                'invoice_date': fields.Date.today(),
                'car_number': waybill.car_number,  # Add car number
                'start_location': waybill.start_address,  # Add start location
                'editable_end_location': waybill.end_address,  # Add end location
                'driver_id': waybill.driver_tin,  # Add driver ID
                'invoice_line_ids': invoice_lines,
            })

            # Create Combined Invoice Model record
            combined_invoice = self.env['combined.invoice.model'].create({
                'invoice_number': waybill.waybill_number,  # waybill number as invoice number
                'invoice_id': waybill.waybill_id_number,   # waybill ID as invoice ID
            })

            # Link the Combined Invoice record to the newly created vendor bill
            vendor_bill.write({'combined_invoice_id': combined_invoice.id})

            # Update waybill with the created invoice ID (if needed)
            waybill.write({'invoice_id': vendor_bill.id})

            # Return action to open the newly created vendor bill
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'account.move',
                'view_mode': 'form',
                'res_id': vendor_bill.id,
                'target': 'current',
            }

        return True




    def _get_or_create_product(self, w_name, product_category_id=None):
        # Ensure the product category is set, fallback to default if not provided
        product_category_id = product_category_id or self.env.ref('product.product_category_all').id
    
        # Try to search for the product template by name
        product_template = self.env['product.template'].search([('name', '=', w_name)], limit=1)
    
        # If the product template doesn't exist, create a new one
        if not product_template:
            product_template = self.env['product.template'].create({
                'name': w_name,
                'categ_id': product_category_id,  # Set the product category
                'type': 'product',
                'uom_id': self.env.ref('uom.product_uom_unit').id,
                'uom_po_id': self.env.ref('uom.product_uom_unit').id,
            })
    
        # If product variants are missing, create one
        if not product_template.product_variant_ids:
            product_variant = self.env['product.product'].create({
                'product_tmpl_id': product_template.id,
                'default_code': w_name,
                'name': w_name,
                'type': 'product',
                'uom_id': self.env.ref('uom.product_uom_unit').id,
                'uom_po_id': self.env.ref('uom.product_uom_unit').id,
            })
        else:
            product_variant = product_template.product_variant_ids[0]
    
        return product_variant











    sale_order_id = fields.Many2one('sale.order', string='Sale Order')

    def create_sale_order(self):
        for waybill in self:
            # Check if a customer already exists for the buyer
            partner = self.env['res.partner'].search([
                ('vat', '=', waybill.buyer_tin),
            ], limit=1)
            
            # If no customer exists, create one
            if not partner:
                partner = self.env['res.partner'].create({
                    'name': waybill.buyer_name,
                    'vat': waybill.buyer_tin,
                })
    
            # Create sale order based on waybill data
            order_lines = [
                (0, 0, {
                    'product_id': self._get_or_create_product(line.w_name).id,  # Use helper method to get or create product
                    'product_uom_qty': line.quantity,
                    'price_unit': line.price,
                })
                for line in waybill.line_ids if not line.xarjang  # Check xarjang and exclude if present
            ]
            
            # Create the sale order
            sale_order = self.env['sale.order'].create({
                'partner_id': partner.id,
                'date_order': fields.Date.today(),
                'car_number': waybill.car_number,  # Add car number
                'start_location': waybill.start_address,  # Add start location
                'editable_end_location': waybill.end_address,  # Add end location
                'driver_id': waybill.driver_tin,  # Add driver ID
                'order_line': order_lines,
            })

            # Create Combined Invoice Model record
            combined_invoice = self.env['combined.invoice.model'].create({
                'invoice_number': waybill.waybill_number,  # waybill number as invoice number
                'invoice_id': waybill.waybill_id_number,   # waybill ID as invoice ID
            })
    
            # Link the Combined Invoice record to the newly created sale order
            sale_order.write({'combined_invoice_id': combined_invoice.id})
    
            # Update waybill with the created sale order ID (if needed)
            waybill.write({'invoice_id': sale_order.id})
    
            # Return action to open the newly created sale order
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'sale.order',
                'view_mode': 'form',
                'res_id': sale_order.id,
                'target': 'current',
            }
    
        return True




    # Other fields...
    xarjang = fields.Many2one('account.account', string='Account', help="Account to use for invoicing")
    customer_invoice_id = fields.Many2one(
        'account.move',
        string='Customer Invoice',
        help="The customer invoice created from this waybill."
    )




    def create_customer_invoice(self):
        for waybill in self:
            _logger.info('Processing Waybill: %s', waybill.waybill_number)
            _logger.info('Customer Name: %s', waybill.buyer_name)
            _logger.info('Customer TIN: %s', waybill.buyer_tin)

            # Create Combined Invoice Model record
            combined_invoice = self.env['combined.invoice.model'].create({
                'invoice_number': waybill.waybill_number,
                'invoice_id': waybill.waybill_id_number,
            })

            # Find or create the partner (customer) based on the waybill's buyer info
            partner = self.env['res.partner'].search([
                ('vat', '=', waybill.buyer_tin),
            ], limit=1)

            if not partner:
                partner = self.env['res.partner'].create({
                    'name': waybill.buyer_name,
                    'vat': waybill.buyer_tin,
                })

            # Prepare invoice lines from waybill lines
            invoice_lines = []
            for line in waybill.line_ids:
                account_id = waybill.xarjang.id if waybill.xarjang else self.env['account.account'].search([], limit=1).id

                invoice_lines.append((0, 0, {
                    'product_id': self._get_or_create_product(line.w_name).id,
                    'quantity': line.quantity,
                    'price_unit': line.price,
                    'account_id': account_id,
                }))

            # Set payment term (replace 'your_payment_term_id' with actual ID)
            # Create customer invoice
            invoice = self.env['account.move'].create({
                'move_type': 'out_invoice',
                'partner_id': partner.id,
                'invoice_date': fields.Date.today(),
                'invoice_line_ids': invoice_lines,
                'combined_invoice_id': combined_invoice.id,
                'invoice_payment_term_id': False,  # Set payment term
                'invoice_date_due': fields.Date.today(),  # Set due date to today's date
            })

            # Update the waybill with the created customer invoice ID
            waybill.write({'customer_invoice_id': invoice.id})

            # Return action to open the newly created customer invoice
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'account.move',
                'view_mode': 'form',
                'res_id': invoice.id,
                'target': 'current',
            }

        
        


    def _get_tax_id(self, vat_type):
        """Helper method to get or create a tax based on vat_type."""
        if vat_type == 0:
            return False  # No tax
        elif vat_type == 1:
            tax = self.env['account.tax'].search([('name', '=', '18% VAT')], limit=1)
            if not tax:
                tax = self.env['account.tax'].create({
                    'name': '18% VAT',
                    'amount': 18.0,
                    'amount_type': 'percent',
                    'type_tax_use': 'sale',
                })
            return tax.id


    def create_internal_delivery(self):
        for waybill in self:
            # Ensure source and destination locations are available, handle missing references
            try:
                source_location = self.env.ref('stock.stock_location_stock')
            except ValueError:
                source_location = self.env['stock.location'].search([('name', '=', 'Stock')], limit=1)
                if not source_location:
                    raise ValidationError("Source location 'WH/Stock' not found in the system.")
    
            try:
                dest_location = self.env.ref('stock.stock_location_stock')
            except ValueError:
                dest_location = self.env['stock.location'].search([('name', '=', 'WH/Stock')], limit=1)
                if not dest_location:
                    raise ValidationError("Destination location 'WH/Inventory' not found in the system.")
            
            # Find or create the partner (customer) based on the waybill's buyer info
            partner = self.env['res.partner'].search([
                ('vat', '=', waybill.buyer_tin),
            ], limit=1)

            if not partner:
                partner = self.env['res.partner'].create({
                    'name': waybill.buyer_name,
                    'vat': waybill.buyer_tin,
                })
    
            # Create a new internal delivery without move_lines initially
            internal_delivery = self.env['stock.picking'].create({
                'picking_type_id': self.env.ref('stock.picking_type_internal').id,  # Ensure this reference is correct
                'partner_id': partner.id,  # No partner for internal transfers
                'location_id': source_location.id,  # Set source location
                'location_dest_id': dest_location.id,  # Set destination location
            })
    
            # Create Combined Invoice Model record
            combined_invoice = self.env['combined.invoice.model'].create({
                'invoice_number': waybill.waybill_number,  # waybill number as invoice number
                'invoice_id': waybill.waybill_id_number,   # waybill ID as invoice ID
            })
    
            # Link the Combined Invoice record to the newly created internal delivery
            internal_delivery.write({'combined_invoice_id': combined_invoice.id})
    
            # Update waybill with the created internal delivery ID (if needed)
            waybill.write({'invoice_id': internal_delivery.id})
    
            # Create stock moves and move lines
            move_lines = []
            for line in waybill.line_ids:  # Assuming `line_ids` is the field containing the lines
                # Get or create the product based on w_name
                product = self._get_or_create_product(line.w_name)  # Assuming line.w_name is used to identify the product
                
                # Create stock move
                stock_move = self.env['stock.move'].create({
                    'name': product.name,
                    'product_id': product.id,
                    'product_uom_qty': line.quantity,
                    'picking_id': internal_delivery.id,
                    'location_id': internal_delivery.location_id.id,  # Source location
                    'location_dest_id': internal_delivery.location_dest_id.id,  # Destination location
                    'state': 'draft',  # Set to 'draft' initially
                })
    
                # Create stock move lines for the stock move
                move_lines.append({
                    'move_id': stock_move.id,
                    'product_id': product.id, # Ensure UoM is provided
                    'location_id': internal_delivery.location_id.id,  # Source location
                    'location_dest_id': internal_delivery.location_dest_id.id,  # Destination location
                    'result_package_id': False,  # Set if using packages
                })
    
            # Update the internal delivery with move lines
            if move_lines:
                self.env['stock.move.line'].create(move_lines)
    
            # Return action to open the newly created internal delivery
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'stock.picking',
                'view_mode': 'form',
                'res_id': internal_delivery.id,
                'target': 'current',
            }

    
            # Create Combined Invoice



    def action_create_internal_delivery(self):
        return self.create_internal_delivery()



    def create_purchase_return(self):
        for waybill in self:
            # Log the relevant waybill information
            _logger.info('Processing Waybill: %s', waybill.waybill_number)  # Replace 'waybill_number' with an appropriate field
            _logger.info('Seller Name: %s', waybill.seller_name)
            _logger.info('Seller TIN: %s', waybill.seller_tin)
    
            # Check if a vendor already exists for the seller
            vendor = self.env['res.partner'].search([
                ('vat', '=', waybill.seller_tin),
            ], limit=1)
            
            # If no vendor exists, create one
            if not vendor:
                if waybill.seller_name:
                    vendor = self.env['res.partner'].create({
                        'name': waybill.seller_name,
                        'vat': waybill.seller_tin,
                    })
                else:
                    _logger.warning('Vendor name is empty for Seller TIN: %s', waybill.seller_tin)
                    raise UserError('Vendor name is empty for Seller TIN: %s' % waybill.seller_tin)

            # Create purchase order based on waybill data
            order_lines = [(0, 0, {
                'product_id': self._get_or_create_product(line.w_name).id,  # Use helper method to get or create product
                'product_qty': line.quantity,
                'price_unit': line.price,
            }) for line in waybill.line_ids]
            
            purchase_order = self.env['purchase.order'].create({
                'partner_id': vendor.id,
                'date_order': fields.Date.today(),
                'order_line': order_lines,
            })

            # Create vendor bill based on the purchase order
            bill_lines = [(0, 0, {
                'product_id': line.product_id.id,
                'quantity': line.product_qty,
                'price_unit': line.price_unit,
                'move_id': purchase_order.id,
            }) for line in purchase_order.order_line]

            vendor_bill = self.env['account.move'].create({
                'move_type': 'in_invoice',
                'partner_id': vendor.id,
                'invoice_date': fields.Date.today(),
                'invoice_line_ids': bill_lines,
            })

            # Create a combined invoice record
            combined_invoice = self.env['combined.invoice.model'].create({
                'invoice_number': waybill.waybill_number,
                'invoice_id': waybill.waybill_id_number,
            })

            # Create a purchase return from the vendor bill
            return_lines = [(0, 0, {
                'product_id': line.product_id.id,
                'quantity': line.quantity,
                'price_unit': line.price_unit,
                'move_id': vendor_bill.id,
            }) for line in vendor_bill.invoice_line_ids]

            purchase_return = self.env['account.move'].create({
                'move_type': 'in_refund',
                'partner_id': vendor.id,
                'invoice_date': fields.Date.today(),
                'invoice_line_ids': return_lines,
            })

            # Link the Combined Invoice record to the newly created purchase return
            purchase_return.write({'combined_invoice_id': combined_invoice.id})

            # Optionally, update the waybill with a reference to the purchase return
            # Make sure to define a `purchase_return_id` field on the `waybill` model if you want to store this reference
            # waybill.write({'purchase_return_id': purchase_return.id})

            # Return action to open the newly created purchase return
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'account.move',
                'view_mode': 'form',
                'res_id': purchase_return.id,
                'target': 'current',
            }

        return True



    def create_inventory_receipt(self):
        for waybill in self:
            # Ensure source and destination locations are available, handle missing references
            try:
                source_location = self.env.ref('stock.stock_location_stock')
            except ValueError:
                source_location = self.env['stock.location'].search([('name', '=', 'Stock')], limit=1)
                if not source_location:
                    raise ValidationError("Source location 'WH/Stock' not found in the system.")
    
            try:
                dest_location = self.env.ref('stock.stock_location_stock')
            except ValueError:
                dest_location = self.env['stock.location'].search([('name', '=', 'WH/Inventory')], limit=1)
                if not dest_location:
                    raise ValidationError("Destination location 'WH/Inventory' not found in the system.")

              # Find or create the partner (customer) based on the waybill's buyer info
            partner = self.env['res.partner'].search([
                ('vat', '=', waybill.buyer_tin),
            ], limit=1)

            if not partner:
                partner = self.env['res.partner'].create({
                    'name': waybill.buyer_name,
                    'vat': waybill.buyer_tin,
                })
    
            # Create a new inventory receipt
            inventory_receipt = self.env['stock.picking'].create({
                'picking_type_id': self.env.ref('stock.picking_type_in').id,  # Ensure this reference is correct
                'location_id': source_location.id,  # Source location
                'location_dest_id': dest_location.id,  # Destination location
                'partner_id': partner.id,  # Set if you have a partner for incoming receipts
            })
    
            # Create Combined Invoice Model record
            combined_invoice = self.env['combined.invoice.model'].create({
                'invoice_number': waybill.waybill_number,  # waybill number as invoice number
                'invoice_id': waybill.waybill_id_number,   # waybill ID as invoice ID
            })
    
            # Link the Combined Invoice record to the newly created inventory receipt
            inventory_receipt.write({'combined_invoice_id': combined_invoice.id})
    
            # Update waybill with the created inventory receipt ID (if needed)
            waybill.write({'invoice_id': inventory_receipt.id})
    
            # Create stock moves and move lines
            move_lines = []
            for line in waybill.line_ids:  # Assuming `line_ids` is the field containing the lines
                # Get or create the product based on w_name
                product = self._get_or_create_product(line.w_name)  # Assuming line.w_name is used to identify the product
                
                # Create stock move
                stock_move = self.env['stock.move'].create({
                    'name': product.name,
                    'product_id': product.id,
                    'product_uom_qty': line.quantity,
                    'picking_id': inventory_receipt.id,
                    'location_id': source_location.id,  # Source location
                    'location_dest_id': dest_location.id,  # Destination location
                    'state': 'draft',  # Set to 'draft' initially
                })
    
                # Create stock move lines for the stock move
                move_lines.append({
                    'move_id': stock_move.id,
                    'product_id': product.id,
                    'location_id': source_location.id,  # Source location
                    'location_dest_id': dest_location.id,  # Destination location
                    'result_package_id': False,  # Set if using packages
                })
    
            # Update the internal delivery with move lines
            if move_lines:
                self.env['stock.move.line'].create(move_lines)
    
            # Confirm the inventory receipt to create move lines
            inventory_receipt.action_confirm()
    
            # Return action to open the newly created inventory receipt
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'stock.picking',
                'view_mode': 'form',
                'res_id': inventory_receipt.id,
                'target': 'current',
            }






















class WaybillLine(models.Model):
    _name = 'waybill.line'
    _description = 'Waybill Line'

    waybill_id = fields.Many2one('waybill', string='Waybill', ondelete='cascade')
    product_id = fields.Many2one('product.template', string='Product', ondelete='set null')
    w_name = fields.Char(string='სახელი')
    quantity = fields.Char(string='რაოდენობა')
    price = fields.Char(string='ფასი')
    amount = fields.Char(string='სრული ფასი')
    bar_code = fields.Char(string='ბარ კოდი')
    a_id = fields.Char(string='ID')
    vat_type= fields.Char(string='დაბეგვრის ტიპი')
    status = fields.Char(string='Status')
    quantity_fact = fields.Char(string='Quantity F')
    xarjang = fields.Many2one('account.account', string='დებეტი|დებეტის ანგარიში')
    product_category_id = fields.Many2one('product.category', string='Product Category', help='Product category for this line')










class WaybillLineHistory(models.Model):
    _name = 'waybill.line.history'
    _description = 'Waybill Line History'

    waybill_id = fields.Many2one('waybill', string='Waybill', ondelete='cascade')
    product_id = fields.Many2one('product.template', string='Product', ondelete='set null')
    w_name = fields.Char(string='სახელი')
    quantity = fields.Char(string='რაოდენობა')
    price = fields.Char(string='ფასი')
    amount = fields.Char(string='სრული ფასი')
    bar_code = fields.Char(string='ბარ კოდი')
    a_id = fields.Char(string='ID')
    vat_type = fields.Char(string='დაბეგვრის ტიპი')
    status = fields.Char(string='Status')
    quantity_fact = fields.Char(string='Quantity F')
    xarjang = fields.Many2one('account.account', string='დებეტი|დებეტის ანგარიში')
    product_category_id = fields.Many2one('product.category', string='Product Category', help='Product category for this line')



