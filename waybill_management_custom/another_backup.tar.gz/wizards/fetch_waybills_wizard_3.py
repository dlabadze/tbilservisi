from odoo import models, fields, api
from odoo.exceptions import UserError
import requests
import xmltodict
import logging as _logger
import xml.etree.ElementTree as ET
from odoo.exceptions import ValidationError
from datetime import datetime

class FetchWaybillswizard3(models.TransientModel):
    _name = 'fetch.waybills.wizard3'
    _description = 'Fetch Waybills wizard3'

    date1 = fields.Date(string='Start Date', required=True, default=fields.Date.today)
    date2 = fields.Date(string='End Date', required=True, default=fields.Date.today)
    
    @api.constrains('date1', 'date2')
    def _check_date_range(self):
        for record in self:
            if record.date1 and record.date2:
                start_date = fields.Date.from_string(record.date1)
                end_date = fields.Date.from_string(record.date2)
                delta = end_date - start_date
                if delta.days > 30:
                    raise ValidationError('The end date must be within 30 days of the start date.')

    def fetch_waybills_3(self):
        try:
            date_str1 = self.date1.strftime('%Y-%m-%d')
            date_str2 = self.date2.strftime('%Y-%m-%d')
    
            # SOAP request URL and headers
            url = "http://services.rs.ge/WayBillService/WayBillService.asmx"
            headers = {
                "Content-Type": "text/xml; charset=utf-8",
                "SOAPAction": "http://tempuri.org/get_waybills"
            }
    
            # SOAP body
            soap_body_waybills = f"""
            <?xml version="1.0" encoding="utf-8"?>
            <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                           xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                           xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
              <soap:Body>
                <get_waybills xmlns="http://tempuri.org/">
                  <su>NEWTESTDATO:206322102</su>
                  <sp>123456Ab!</sp>
                  <itypes>5</itypes>
                  <buyer_tin/>
                  <statuses/>
                  <car_number/>
                  <begin_date_s xsi:nil="true"/>
                  <begin_date_e xsi:nil="true"/>
                  <create_date_s>{date_str1}T00:00:00+04:00</create_date_s>
                  <create_date_e>{date_str2}T23:59:59+04:00</create_date_e>
                  <delivery_date_s xsi:nil="true"/>
                  <delivery_date_e xsi:nil="true"/>
                  <full_amount xsi:nil="true"/>
                  <waybill_number/>
                  <close_date_s xsi:nil="true"/>
                  <close_date_e xsi:nil="true"/>
                  <s_user_ids/>
                  <comment/>
                </get_waybills>
              </soap:Body>
            </soap:Envelope>
            """
    
            # Perform request
            response = requests.post(url, data=soap_body_waybills.strip(), headers=headers)
            response.raise_for_status()  # Ensure we notice bad responses
            _logger.info("SOAP request successful, processing response")
    
            response_text = response.text
            _logger.info(f"SOAP response received: {response_text}")
    
            # Parse response
            data = xmltodict.parse(response_text)
            waybills = data.get('soap:Envelope', {}).get('soap:Body', {}).get('get_waybillsResponse', {}).get('get_waybillsResult', {}).get('WAYBILL_LIST', {}).get('WAYBILL', [])
    
            if not waybills:
                _logger.warning("No waybills found in the response")
                return {'type': 'ir.actions.act_window_close'}
    
            _logger.info(f"Found {len(waybills)} waybills to process")
    
            # Get models
            waybill_obj = self.env['waybill']
            waybill_line_obj = self.env['waybill.line']
            waybill_line_history_obj = self.env['waybill.line.history']
    
            for waybill_data in waybills:
                waybill_number = waybill_data.get('WAYBILL_NUMBER', '').strip()
                
                if not waybill_number:
                    _logger.warning(f"Skipping waybill with empty waybill_number: {waybill_data}")
                    continue  # Skip processing if waybill number is empty
    
                existing_waybill = waybill_obj.search([('waybill_number', '=', waybill_number)], limit=1)
                _logger.info(f"Processing waybill number: {waybill_number}")
    
                waybill_values = {
                    'waybill_number': waybill_data.get('WAYBILL_NUMBER', ''),
                    'create_date': waybill_data.get('CREATE_DATE', ''),
                    'buyer_tin': waybill_data.get('BUYER_TIN', ''),
                    'buyer_name': waybill_data.get('BUYER_NAME', ''),
                    'seller_name': waybill_data.get('SELLER_NAME', ''),
                    'seller_tin': waybill_data.get('SELLER_TIN', ''),
                    'start_address': waybill_data.get('START_ADDRESS', ''),
                    'end_address': waybill_data.get('END_ADDRESS', ''),
                    'transport_cost': waybill_data.get('TRANSPORT_COST', '0'),
                    'full_amount': waybill_data.get('FULL_AMOUNT', '0'),
                    'activate_date': waybill_data.get('ACTIVATE_DATE', ''),
                    's_user_id': waybill_data.get('S_USER_ID', ''),
                    'begin_date': waybill_data.get('BEGIN_DATE', ''),
                    'is_confirmed': waybill_data.get('IS_CONFIRMED', ''),
                    'is_corrected': waybill_data.get('IS_CORRECTED', ''),
                    'seller_st': waybill_data.get('SELLER_ST', ''),
                    'is_med': waybill_data.get('IS_MED', ''),
                    'waybill_comment': waybill_data.get('WAYBILL_COMMENT', ''),
                    'driver_tin': waybill_data.get('DRIVER_TIN', ''),
                    'driver_name': waybill_data.get('DRIVER_NAME', ''),
                    'car_number': waybill_data.get('CAR_NUMBER', ''),
                    'delivery_date': waybill_data.get('DELIVERY_DATE', ''),
                    'close_date': waybill_data.get('CLOSE_DATE', ''),
                    'invoice_id': waybill_data.get('INVOICE_ID', ''),
                    'waybill_id_number': waybill_data.get('ID', ''),
                    'waybill_type': waybill_data.get('TYPE', ''),
                    'error_text': 'რეალიზაციის დაბრუნება',
                }
    
                if not existing_waybill:
                    # Create new waybill record if it doesn't exist
                    waybill_record = waybill_obj.create(waybill_values)
                    _logger.info(f"Waybill record created: {waybill_number}")
                else:
                    waybill_record = existing_waybill
                    _logger.info(f"Waybill record exists: {waybill_number}")
    
                waybill_id_number = waybill_data.get('ID', '')  # Get waybill_id_number for the next request
    
                # Fetch waybill lines
                rs_acc = 'NEWTESTDATO:206322102'
                rs_pass = '123456Ab!'
                url = "http://services.rs.ge/WayBillService/WayBillService.asmx"
                headers = {
                    "Content-Type": "text/xml; charset=utf-8",
                    "SOAPAction": "http://tempuri.org/get_waybill"
                }
                payload = f"""<?xml version="1.0" encoding="utf-8"?>
                        <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                          <soap:Body>
                            <get_waybill xmlns="http://tempuri.org/">
                              <su>{rs_acc}</su>
                              <sp>{rs_pass}</sp>
                              <waybill_id>{waybill_id_number}</waybill_id>
                            </get_waybill>
                          </soap:Body>
                        </soap:Envelope>
                        """
                response = requests.post(url, data=payload, headers=headers)
                response.raise_for_status()
                response_text = response.text
                _logger.info(f"SOAP response for waybill details received: {response_text}")
                
                root = ET.fromstring(response_text)
                namespace = {'soap': 'http://schemas.xmlsoap.org/soap/envelope/'}
    
                goods_list = []
                for goods in root.findall('.//GOODS', namespaces=namespace):
                    item = {
                        'w_name': goods.find('W_NAME').text.strip() if goods.find('W_NAME') is not None and goods.find('W_NAME').text else '',
                        'quantity': goods.find('QUANTITY').text.strip() if goods.find('QUANTITY') is not None and goods.find('QUANTITY').text else '',
                        'price': goods.find('PRICE').text.strip() if goods.find('PRICE') is not None and goods.find('PRICE').text else '',
                        'amount': goods.find('AMOUNT').text.strip() if goods.find('AMOUNT') is not None and goods.find('AMOUNT').text else '',
                        'bar_code': goods.find('BAR_CODE').text.strip() if goods.find('BAR_CODE') is not None and goods.find('BAR_CODE').text else '',
                        'a_id': goods.find('A_ID').text.strip() if goods.find('A_ID') is not None and goods.find('A_ID').text else '',
                        'vat_type': goods.find('VAT_TYPE').text.strip() if goods.find('VAT_TYPE') is not None and goods.find('VAT_TYPE').text else '',
                    }
                    goods_list.append(item)
    
                # Fetch existing lines
                existing_lines = waybill_line_obj.search([('waybill_id', '=', waybill_record.id)])
                existing_line_names = existing_lines.mapped('w_name')
    
                if not goods_list:
                    _logger.warning(f"No goods list found for waybill number {waybill_number}")
                    continue
    
                new_line_names = [line['w_name'] for line in goods_list]
    
                if any(name not in existing_line_names for name in new_line_names):
                    _logger.info(f"Non-existent lines detected for waybill {waybill_number}, archiving existing lines")
                    # Archiving existing lines
                    for line in existing_lines:
                        history_data = {
                            'product_id': line.product_id.id,
                            'w_name': line.w_name,
                            'quantity': line.quantity,
                            'price': line.price,
                            'amount': line.amount,
                            'bar_code': line.bar_code,
                            'a_id': line.a_id,
                            'vat_type': line.vat_type,
                            'status': line.status,
                            'quantity_fact': line.quantity_fact,
                            # Provide a value for `xarjang
                        }
                        waybill_line_history_obj.create(history_data)
    
                existing_lines.unlink()  # Remove existing lines
    
                # Create new lines
                for item in goods_list:
                    product = self.env['product.product'].search([('barcode', '=', item['bar_code'])], limit=1)
                    line_values = {
                        'w_name': item['w_name'],
                        'quantity': item['quantity'],
                        'price': item['price'],
                        'amount': item['amount'],
                        'bar_code': item['bar_code'],
                        'a_id': item['a_id'],
                        'vat_type': item['vat_type'],
                        'waybill_id': waybill_record.id,
                        'product_id': product.id if product else False  # Link to the product if it exists
                    }
                    waybill_line_obj.create(line_values)
    
                _logger.info(f"New lines created for waybill {waybill_number}")

            return {'type': 'ir.actions.act_window_close'}

        except requests.exceptions.RequestException as e:
            _logger.error(f"Request failed: {e}")
            raise UserError(f"Request failed: {e}")

        except UserError as ue:
            _logger.error(f"Error processing waybills: {ue}")
            raise

        except Exception as e:
            _logger.error(f"Unexpected error: {e}")
            raise UserError(f"Unexpected error occurred: {e}")

